﻿using UnityEngine;

public class MenuScript : MonoBehaviour
{
    public void restart()
    {
        Application.LoadLevel("GameLevel");
    }

    public void onClickQuit()
    {
        Application.LoadLevel("GameOver");
    }

    public void onClickPause()
    {
        FindObjectOfType<game>().checkUserInput();
    }
}
