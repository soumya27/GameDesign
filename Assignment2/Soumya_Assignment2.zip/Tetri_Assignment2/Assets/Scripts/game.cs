﻿using UnityEngine;
using UnityEngine.UI;

public class game : MonoBehaviour
{

    public static int width = 10;
    public static int height = 20;

    public static Transform[,] grid = new Transform[width, height];

    public int scoreOneLine = 30;
    public int scoreTwoLine = 60;
    public int scoreThreeLine = 90;
    public int scoreFourLine = 1200;

    private int rowsCleared = 0;

    public Text score;
    private int intScore;

    public GameObject background;
    public Text pauseText;
    public static bool isPaused;
    private AudioSource audio;
    public AudioClip clear;

    private Vector2 savedTetrominoPosition = new Vector2(-6.5f, 10);
    private GameObject savedTetromino;
    private GameObject nextTetromino;

    public int maxSawp = 5;
    private int currentSwap = 0;

    void Start()
    {
        spawnNext();
        audio = GetComponent<AudioSource>();
        setBackground(Color.white);
        isPaused = false;
    }


    void Update()
    {
        updateScore();
        score.text = intScore.ToString();
        saveInput();
    }

    public void saveInput()
    {
        if (Input.GetKeyUp(KeyCode.S))
        {
            GameObject tempNext = GameObject.FindGameObjectWithTag("current");
            saveTetromino(tempNext.transform);
        }
    }

    public void checkUserInput()
    {   
        if(Time.timeScale == 1)
        {
            pauseGame();
            pauseText.text = "Resume";
        }
        else
        {
            resumeGame();
            pauseText.text = "Pause";
        }
    }

    public void pauseGame()
    {
        Time.timeScale = 0;
        isPaused = true;
    }

    public void resumeGame()
    {
        Time.timeScale = 1;
        isPaused = false;
    }

    public void setBackground(Color color)
    {
        background.GetComponent<Renderer>().material.color =  color;
    }

    public void playLineClear()
    {
        audio.PlayOneShot(clear);
    }

    public void updateScore()
    {
        if (rowsCleared > 0)
        {
            switch (rowsCleared)
            {
                case 1:
                    intScore += scoreOneLine;
                    break;
                case 2:
                    intScore += scoreTwoLine;
                    break;
                case 3:
                    intScore += scoreThreeLine;
                    break;
                case 4:
                    intScore += scoreFourLine;
                    break;
            }

            rowsCleared = 0;
            playLineClear();
        }
    }

    public bool isAboveGrid(tetriminos tetromino)
    {
        for(int x =0; x< width; x++)
        {
            foreach(Transform mino in tetromino.transform)
            {
                Vector2 roundPosition = Round(mino.position);
                if (roundPosition.y > height)
                    return true;
            }
        }
        return false;
    }

    public bool isHalfGrid(tetriminos tetromino)
    {
        for(int x =0; x< width; x++)
        {
            foreach (Transform mino in tetromino.transform)
            {
                Vector2 roundPosition = Round(mino.position);
                if (roundPosition.y > height/2)
                    return true;
            }
        }
        return false;
    }

    public void GameOver()
    {
        Application.LoadLevel("GameOver");
    }

    private bool isRowComplete(int y)
    {
        for(int x=0; x<width; x++)
        {
            if (grid[x, y] == null)
                return false;
        }
        rowsCleared++;
        return true;
    }

    private void deleteMino(int y)
    {
        for(int x =0; x< width; x++)
        {
            Destroy(grid[x, y].gameObject);
            grid[x, y] = null;
        }
    }

    private void moveRowDown(int y)
    {
        for (int x = 0; x < width; x++)
        {
           if(grid[x,y] != null)
            {
                grid[x, y - 1] = grid[x, y];
                grid[x, y] = null;
                grid[x, y - 1].position += new Vector3(0,-1,0); 
            }
        }
    }

    private void moveAllRows(int y)
    {
        for (int i=y; i< height; i++)
        {
            moveRowDown(i);
        }
    }

    public void deleteRow()
    {
        for(int y=0; y <height; y++)
        {
            if (isRowComplete(y))
            {
                deleteMino(y);
                moveAllRows(y + 1);
                y--;
            }
        }
    }

    public void updateGrid(tetriminos tetromino)
    {
        for (int y =0; y < height; y++)
        {
            for (int x = 0; x<width; x++)
            {
                if (grid[x, y] != null)
                {
                    if(grid[x,y].parent == tetromino.transform)
                    {
                        grid[x, y] = null;
                    }
                }
            }
        }

        foreach(Transform mino in tetromino.transform)
        {
            Vector2 roundPos = Round(mino.position);
            if( roundPos.y< height)
            {
                grid[(int)roundPos.x, (int)roundPos.y]=mino;
            }
        }
    }

    public void spawnNext()
    {
        GameObject next = (GameObject)Instantiate(Resources.Load(getRandomTetromino(),typeof(GameObject)),
            new Vector2(5.0f, 20.0f), Quaternion.identity);
        next.tag = "current";
        currentSwap = 0;
    }

    public void saveTetromino(Transform t)
    {
        currentSwap++;
        if (currentSwap > maxSawp)
            return;
        if (savedTetromino != null)
        {
            GameObject temp = GameObject.FindGameObjectWithTag("Saved");
            temp.transform.localPosition = new Vector2(width / 2, height);
            savedTetromino = (GameObject)Instantiate(t.gameObject);
            savedTetromino.GetComponent<tetriminos>().enabled = false;
            savedTetromino.transform.localPosition = savedTetrominoPosition;
            savedTetromino.tag = "Saved";
            nextTetromino = (GameObject)Instantiate(temp);
            nextTetromino.GetComponent<tetriminos>().enabled = true;
            nextTetromino.transform.localPosition = new Vector2(width / 2, height);
            nextTetromino.tag = "current";

            DestroyImmediate(t.gameObject);
            DestroyImmediate(temp);
        }
        else
        {
            savedTetromino = (GameObject)Instantiate(GameObject.FindGameObjectWithTag("current"));
            savedTetromino.GetComponent<tetriminos>().enabled = false;
            savedTetromino.transform.localPosition = savedTetrominoPosition;
            savedTetromino.tag = "Saved";

            DestroyImmediate(GameObject.FindGameObjectWithTag("current"));
            spawnNext();
        }
    
    }

    public bool isInsideGrid(Vector2 position)
    {
        return (int)position.x >= 0 && (int)position.x < width && (int)position.y >= 0;
    }

    public Vector2 Round(Vector2 position)
    {
        return new Vector2(Mathf.Round(position.x), Mathf.Round(position.y));
    }

    private string getRandomTetromino()
    {
        int randomTetromino = Random.Range(1, 8);
        string tetrominoName = "Tetromino_T";
        switch (randomTetromino)
        {
            case 1:
                tetrominoName = "Tetromino_T";
                break;
            case 2:
                tetrominoName = "Tetromino_Long";
                break;
            case 3:
                tetrominoName = "Tetromino_L";
                break;
            case 4:
                tetrominoName = "Tetromino_s";
                break;
            case 5:
                tetrominoName = "Tetromino_Square";
                break;
            case 6:
                tetrominoName = "Tetromino_J";
                break;
            case 7:
                tetrominoName = "Tetromino_Z";
                break;
        }

        return "Prefabs/" + tetrominoName;
    }

    public Transform getTranformAtGridPosition (Vector2 position)
    {
        if( position.y > height -1)
        {
            return null;
        }else
        {
            return grid[(int)position.x, (int)position.y];
        }
    }
}
