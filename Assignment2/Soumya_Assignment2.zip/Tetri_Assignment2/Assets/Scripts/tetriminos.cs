﻿using UnityEngine;

public class tetriminos : MonoBehaviour
{
    float fall = 0;
    public float fallSpeed = 1;

    public bool allowRotation = true;
    public bool limitedRotation = false;

    void Update()
    {
        if(!game.isPaused)
            checkUserInput();
    }

    void checkUserInput()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.position += new Vector3(1, 0, 0);
            if (!isValidPosition())
            {
                transform.position += new Vector3(-1, 0, 0);
            } else
            {
                FindObjectOfType<game>().updateGrid(this);
            }
            
        } else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.position += new Vector3(-1, 0, 0);
            if (!isValidPosition())
            {
                transform.position += new Vector3(1, 0, 0);
            } else
            {
                FindObjectOfType<game>().updateGrid(this);
            }
        }
        else if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            if (allowRotation)
            {
                if (limitedRotation && transform.rotation.eulerAngles.z >= 90) //limited rotation
                {
                    transform.Rotate(0, 0, transform.rotation.eulerAngles.z * -1);
                }
                else
                {
                    transform.Rotate(0, 0, 90); // rotate along z axis
                }
                if (!isValidPosition())
                {
                   if(limitedRotation)
                    {
                        transform.Rotate(0, 0,transform.rotation.eulerAngles.z *-1);
                    }
                   else
                    {
                        transform.Rotate(0, 0, -90);
                    }
                } else
                {
                    FindObjectOfType<game>().updateGrid(this);
                }
            }
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow) || Time.time - fall >= fallSpeed)
        {
            transform.position += new Vector3(0, -1, 0);
            if (!isValidPosition())
            {
                transform.position += new Vector3(0, 1, 0);
                FindObjectOfType<game>().deleteRow();
                if (FindObjectOfType<game>().isAboveGrid(this))
                {
                    FindObjectOfType<game>().GameOver();
                }
                if (FindObjectOfType<game>().isHalfGrid(this))
                {
                    FindObjectOfType<game>().setBackground(Color.red);
                } else
                {
                    FindObjectOfType<game>().setBackground(Color.white);
                }
                enabled = false;
                tag = "untagged";
                FindObjectOfType<game>().spawnNext();
            } else
            {
                FindObjectOfType<game>().updateGrid(this);
            }
            fall = Time.time;
        }

    }

    bool isValidPosition()
    {
        foreach(Transform mino in transform)
        {
            Vector2 roundPos = FindObjectOfType<game>().Round(mino.position);
            if(FindObjectOfType<game>().isInsideGrid(roundPos) == false )
            {
                return false;
            }
            if (FindObjectOfType<game>().getTranformAtGridPosition(roundPos) != null &&
                FindObjectOfType<game>().getTranformAtGridPosition(roundPos).parent != transform)
            {
                return false;
            }
        }
        return true;
    }
}
