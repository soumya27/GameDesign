﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{

    public GameObject hazard;
    public GameObject stars;

    public Vector3 spawnValues;
    public int hazardCount;
    public int starsCount;

    public float spawnWait;
    public float startWait;
    public float waitForNext;

    private void Start()
    {
        StartCoroutine(SpawnWaves());
    }

    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(startWait);
        while (true) {
            yield return new WaitForSeconds(waitForNext);
            for (int i = 0; i < hazardCount; i ++) { 
                Vector3 spawnPosition = new Vector3(UnityEngine.Random.Range(-spawnValues.x,spawnValues.x), spawnValues.y, spawnValues.z);
                Quaternion spawnRotation = Quaternion.identity;
                Instantiate(hazard, spawnPosition, spawnRotation);

                spawnPosition = new Vector3(UnityEngine.Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                Instantiate(stars, spawnPosition,spawnRotation);
                yield return new WaitForSeconds(spawnWait);
            }
        }
    }
}
    