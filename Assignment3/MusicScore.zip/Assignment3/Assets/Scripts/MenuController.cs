﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuController : MonoBehaviour
{

    private AudioSource audio;
    public AudioClip playerExplosion;

    private void Start()
    {
        audio = GetComponent<AudioSource>();
        audio.PlayOneShot(playerExplosion);
        Debug.Log("Game over");
    }

    public void onClickNew()
    {
        Application.LoadLevel("MainScene");
          
    }
}
