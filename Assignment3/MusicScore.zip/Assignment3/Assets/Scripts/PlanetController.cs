﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlanetController : MonoBehaviour
{
    private Rigidbody rigidbody;
    public float speed;
    void Start()
    {
        rigidbody = GetComponent<Rigidbody>(); 
       
    }

    void Update()
    {
        rigidbody.velocity = -(transform.forward * speed);
        //transform.Translate(new Vector3(0.2f, 0.0f, -0.2f) * 0.4f);
    }
}
