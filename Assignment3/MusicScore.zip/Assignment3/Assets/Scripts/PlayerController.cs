﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rigidbody;
    public Text score; 
    public float speed;
    public float tilt;
    public float maxX, minX;
    private int scoreValue;
    private AudioSource audio;
    public AudioClip starCollect;
    public AudioClip playerExplosion;
    public AudioClip scoreMusic;

    private void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
        audio = GetComponent<AudioSource>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("stars"))
        {
            audio.PlayOneShot(starCollect);
            other.gameObject.SetActive(false);
            updateScore();
        }
        if (other.gameObject.CompareTag("starsPart"))
        {
            other.gameObject.SetActive(false);
        }
        if (other.gameObject.CompareTag("planets"))
        {
            Destroy(other.gameObject);
            Application.LoadLevel("Gameover");
        }
    }

    private void updateScore()
    {
        audio.PlayOneShot(scoreMusic);
        scoreValue += 10;
        score.text = "Score: " + scoreValue.ToString();
    }

    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        Vector3 movement = new Vector3(moveHorizontal, 0.0f, rigidbody.position.z);
        rigidbody.velocity = movement * speed;
        rigidbody.position = new Vector3(Mathf.Clamp(rigidbody.position.x, minX, maxX), 0.0f, 2.0f);
    }
}
