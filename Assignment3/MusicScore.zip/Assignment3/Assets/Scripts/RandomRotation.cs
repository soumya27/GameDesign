﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomRotation : MonoBehaviour
{
    private Rigidbody rigidbody;
    public float tumble;

    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
        //rigidbody.angularVelocity = new Vector3(0.6f, 0.0f,0.0f);
    }

}
